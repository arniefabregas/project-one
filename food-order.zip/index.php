

<?php include('menu.php');
      
?>

        <!----Menu Content Section Starts Here------->
        <div class="main-menu">
            <div class="wrapper">
                <h1>Dashboard</h1>
                <br><br>
                
                    <?php
                    if(isset($_SESSION['login']))
                        {   echo ($_SESSION['login']);
                            unset($_SESSION['login']);
                        }
                    
                    ?>

                <br><br>

                
                <div class="col-4 text-center">

                <?php
                    //sql query
                    $sql = "SELECT * FROM tb_category";
                    //execute query
                    $res = mysqli_query($conn, $sql);
                    //count
                    $count = mysqli_num_rows($res);                    
                ?>
                    <h1><?php echo $count; ?></h1>
                    <br>
                    Categories
                </div>
                <div class="col-4 text-center">
                <?php
                    //sql query
                    $sql2 = "SELECT * FROM tb_food";
                    //execute query
                    $res2 = mysqli_query($conn, $sql2);
                    //count
                    $count2 = mysqli_num_rows($res2);                    
                ?>
                    <h1><?php echo $count2; ?></h1>
                    <br>
                    Foods
                </div>
                <div class="col-4 text-center">
                <?php
                    //sql query
                    $sql3 = "SELECT * FROM tb_order";
                    //execute query
                    $res3 = mysqli_query($conn, $sql3);
                    //count
                    $count3 = mysqli_num_rows($res3);                    
                ?>
                    <h1><?php echo $count3; ?></h1>
                    <br>
                    Total Orders
                </div>
                <div class="col-4 text-center">
                <?php
                    
                    $sql4 = "SELECT SUM(total) AS Total FROM tb_order WHERE status='Delivered'"; 
                            
                    //execute the query
                    $res4 = mysqli_query($conn, $sql4);
                    //get the value
                    $row4 = mysqli_fetch_assoc($res4);

                    //get teh total revenue
                    $totalsales = $row4['Total'];

                ?>
                    <h1>$<?php echo $totalsales; ?></h1>
                    <br>
                    Total Sales 
                </div>

                <div class="clearfix"></div>
            </div>
        </div>
        <!----Menu Content Section Ends Here--------->

        <?php include('footer.php');?>
      

