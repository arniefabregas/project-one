

<?php
   
    ob_start();
  
    session_start();


    //create constants to store non-repeating values
    define('SITEURL', 'http://localhost/food-order/');
    define('LOCALHOST', 'localhost');  //localhost assigned to LOCALHOST
    define('DB_USERNAME', 'root');      //root assigned to DB_USERNAME  
    define('DB_PASSWORD', '');          //blank password assigned to DB_PASSWORD
    define('DB_NAME', 'food_order');    //database name assigned to DB_NAME

    $conn=mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD) or die(mysqli_error());            //database connection
    $db_select=mysqli_select_db($conn, DB_NAME) or die(mysqli_error());         //selecting database

    

?>