  <!----Footer Section Starts------->
  <div class="footer">
            <div class="wrapper">
                <div class="footer-col">
                    <p>2021 All Rights Reserved | 
                        <a href="https://www.gravitassolutionsph.com" target="_blank">Arnie Fabregas @Gravitas Solutions Philippines</a>
                    </p>
                </div>
            </div>
        </div>
        <!----Footer Section Ends--------->

       
    </body>    

</html>
